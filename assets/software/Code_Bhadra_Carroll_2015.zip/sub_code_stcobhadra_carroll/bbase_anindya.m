function [B] = bbase_anindya(x, knots, deg);
% Construct B-spline basis
dx=diff(knots);
dx=dx(1);
knots=[min(knots)-dx; knots; max(knots) + dx];
knots=knots';
m = length(x);
n = length(knots);
X = repmat(x, 1, n);
T = repmat(knots, m, 1);
P = (X - T) .^ deg .* (X > T);
n = size(P, 2);
D = diff(eye(n), deg + 1) / (gamma(deg + 1) * dx ^ deg);
B = (-1) ^ (deg + 1) * P * D';
