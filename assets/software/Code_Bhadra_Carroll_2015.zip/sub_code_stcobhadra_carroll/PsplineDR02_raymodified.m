function  fit = PsplineDR02_raymodified(x,y,degree,nknots,extrapen, ...
					penwt,boundstab,knots,istd, ...
					 myxgrid);
%
%	Fits a P-spline to univariate x's with Demmler-Reinsch
%	algorithm.
%
%
%	USAGE:  fit = PsplineDR02(x,y,degree,nknots,extrapen,penwt,boundstab,
%		knots);
%
%
%
%		INPUT - REQUIRED
%	x = independent variable (univariate)
%	y = response (same length as x)
%
%		INPUT - OPTIONAL
%	degree = degree of the spline (default is 2)
%	nknots = number of knots (default min of floor(.3*n) and 20)
%	extrapen: if 1 then the x^degree term is penalized; if 0 then not
%			(default is 0)
%	penwt = trial values of the penalty weight (one is chosen by 
%		minimizing gcv (default is logspace(-12,12,100))
%	boundstab = parameter passed to quantileknots (see that program)
%	knots (default is to generate nknots using the program
%		quantileknots)
%	istd = 1 if x and y are to be standardized before computation
%		(default = 1)
%	
%		OUTPUT
%	Returns a structure "fit" with the following components:
%
%	yhat = fitted values (same length as x)
%	beta = spline coefficients
%	gcv = vector of gcv values (same length as penwt)
%	imin = index of penwt where minimum of gcv occurs
%	dffit = degrees of freedom of the smoother (same length as penwt)
%	knots = knots (length = nknots)
%	postvarbeta = posterior variance of beta (from a Bayesian model)
%	postvaryhat = posterior variance of yhat (from a Bayesian model)
%	xm = design matrix of the spline (not returned if n > 1000)
%	xx = xm' * xm
%	a =  penwt(imin)
%	penwt
%	sigma2hat
%	dfres
%	varbeta
%	stdyhat
%	yhatder
%	postvaryhatder
%	ulimit
%	llimit
%	ulimitder
%	llimitder
%
%		That is, 
%	fit = struct( ...
%	'yhat',yhat,'beta',beta,'gcv',gcv,'imin',imin,'dffit',dffit, ...
%	'knots',knots,'postvarbeta',postvarbeta,'postvaryhat',postvaryhat, ...
%	'xm',xm,'xx',xx,'a',a,'penwt',penwt,'sigma2hat',sigma2hat, ...
%	'dfres',dfres,'varbeta',varbeta,'stdyhat',stdyhat, ...
%	'yhatder',yhatder,'postvaryhatder',postvaryhatder, ...
%	'ulimit',ulimit,'llimit',llimit,'ulimitder',ulimitder, ...
%	'llimitder',llimitder,'asr',asr) ;
%
%
%	CALLS: powerbasis01, quantileknots
%
%	Last edit: 6/23/2000
%


n = size(x,1) ;

if (nargin < 10 | isempty(myxgrid) == 1) ;
	myxgrid = linspace(min(x),max(x),200)' ;
end ;

if (nargin < 9 | isempty(istd) == 1) ;
	istd = 1 ;
end ;


if (nargin < 7 | isempty(boundstab) == 1) ;
	boundstab = 0 ;
end ;

if (nargin < 6 | isempty(penwt) == 1) ;
	penwt = logspace(-12,12,100) ;
end ;

if (nargin < 5 | isempty(extrapen) == 1) ;
	extrapen = 0 ;
end ;

if (nargin < 4 | isempty(nknots) == 1) ;
	nknots = min([floor(.3*n), 20]) ;
end ;


if (nargin < 8 | isempty(knots) == 1) ;
	knots = quantileknots(x,nknots,boundstab) ;
else ;
	nknots = length(knots) ;
end ;

if (nargin < 3 | isempty(degree) == 1) ;
	degree = 2 ;
end ;

istd2 = istd;
istd  = 0;
if istd == 1 ;
	stdx = std(x) ;
	meanx = mean(x) ;
	x = (x - meanx) ./ stdx ;
	meany = mean(y) ;
	y = y - meany ;
	knots = (knots - meanx) ./ stdx ;
end ;

n = length(x) ;

xm = powerbasis01(x,degree,knots) ;
xx = xm'*xm ;


if extrapen == 1 ;
	id = [zeros(1,degree)  ones(1,nknots+1)] ;
else ;
	id = [zeros(1,degree+1)  ones(1,nknots)] ;
end ;
D = diag(id) ;


[R,qp]=chol(xx + 1000*eps*eye(size(xx,1)) ) ;
if qp > 0;
  [R,qp]=chol(xx + 2000*eps*eye(size(xx,1)) ) ;
end;
if qp > 0;
  [R,qp]=chol(xx + 4000*eps*eye(size(xx,1)) ) ;
end;
if qp > 0;
  [R,qp]=chol(xx + 8000*eps*eye(size(xx,1)) ) ;
end;

B = inv(R') ;
[U,C] = eig(B*D*B') ;
Z = xm*B'*U ;

Zy = Z'*y ;
ZZ=Z'*Z ;

m = length(penwt) ; 
beta = zeros(size(xm,2),m) ;
%yhat = zeros(n,m) ;
asr = zeros(m,1) ;
gcv = asr ;
trsd = asr ;
trsdsd = asr ;
dfres = asr ;
ssy = y'*y ;

	for i=1:m ;
	oneld = 1 ./ (1 + penwt(i)*diag(C)) ;
	trsd(i) = sum(oneld ) ;
	alpha(:,i) = (Zy) .* oneld ;
	asr(i) =  (ssy - 2*Zy'*alpha(:,i) + alpha(:,i)'*ZZ*alpha(:,i))/n ;
	trsdsd(i) = sum(oneld.*oneld) ;
	dfres(i) = n -2*trsd(i) + trsdsd(i) ;
	gcv(i) = asr(i) / (1-trsd(i)/n)^2 ;
	end ;

imin = min(find(  (gcv==min(gcv)) ) ) ;
a = penwt(imin) ;

dffit= trsd ;
alpha = alpha(:,imin) ;
beta = B'* U * alpha ;
dbeta = length(beta) ;
yhat = Z*alpha ;
sigma2hat = n*asr(imin) ./ dfres(imin) ;

oneld = 1 ./ (1 + penwt(imin)*diag(C)) ;
postvaralpha = sigma2hat*diag(oneld);
postvaryhat = (Z.*(Z*postvaralpha))*ones(dbeta,1) ;
postvarbeta = B'*U*postvaralpha*U'*B ;

Z = [] ;

xmder = xm ;


xmder(:,1) = 0*xmder(:,1) ;

for i = 2:degree+1 ;
	xmder(:,i) = (i-1)*(abs(xm(:,i))).^( (i-2)/(i-1)  ) .* (sign(x)).^(i-2);
end ;

for i=degree+2:degree+1+nknots ;
	xmder(:,i) = degree* (abs(xm(:,i))).^(  (degree-1)/degree ) ...
		.* (xm(:,i) > 0);
end ;



yhatder = xmder*beta ;
postvaryhatder = ((xmder*postvarbeta).*xmder)*ones(dbeta,1) ;

clear xmder ;

if istd == 1 ;
	yhat = yhat + meany ;
end ;
ulimit = yhat + 2*sqrt(postvaryhat) ;
llimit = yhat - 2*sqrt(postvaryhat) ;
ulimitder = yhatder + 2*sqrt(postvaryhatder) ;
llimitder = yhatder - 2*sqrt(postvaryhatder) ;

xgrid = linspace(min(myxgrid),max(myxgrid),length(myxgrid))' ;
xgridm = powerbasis01(xgrid,degree,knots) ;

if istd == 1 ;
	xgrid = meanx + stdx*xgrid ;
	mhat = meany + xgridm*beta ;
else ;
	mhat = xgridm*beta ;
end ;


if n < 10001 ;
fit = struct('yhat',yhat,'beta',beta,'gcv',gcv,'imin',imin,'dffit',dffit, ...
	'knots',knots,'postvarbeta',postvarbeta,'postvaryhat',postvaryhat, ...
	'xm',xm,'xx',xx,'a',a,'penwt',penwt,'sigma2hat',sigma2hat, ...
	'dfres',dfres, ...
	'yhatder',yhatder,'postvaryhatder',postvaryhatder, ...
	'ulimit',ulimit,'llimit',llimit,'ulimitder',ulimitder, ...
	'llimitder',llimitder, ...
	'asr',asr,'xgrid',xgrid,'mhat',mhat,'istd2',istd2) ;
else ;
fit = struct('yhat',yhat,'beta',beta,'gcv',gcv,'imin',imin,'dffit',dffit, ...
	'knots',knots,'postvarbeta',postvarbeta,'postvaryhat',postvaryhat, ...
	'xx',xx,'a',a,'penwt',penwt,'sigma2hat',sigma2hat, ...
	'dfres',dfres, ...
	'yhatder',yhatder,'postvaryhatder',postvaryhatder, ...
	'ulimit',ulimit,'llimit',llimit,'ulimitder',ulimitder, ...
	'llimitder',llimitder, ...
	'asr',asr,'xgrid',xgrid,'mhat',mhat,'istd2',istd2) ;

end ;
