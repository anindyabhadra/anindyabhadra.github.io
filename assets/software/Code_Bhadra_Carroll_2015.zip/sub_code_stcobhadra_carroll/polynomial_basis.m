function design = polynomial_basis(xx,degree);
%
% This programs computes the basis functions for
% a polynomial of a fixed degree >= 1
%
% INPUT:
%      xx        = vector of predictors
%      degree    = degree of the polynomial (assumed >= 1)
%
% OUTPUT:
%      design = n by (1+degree) matrix
%
design = [ones(rows(xx),1) xx];
jj = 1;
while jj < degree;
    design = [design (xx .^ (jj+1))];
    jj = jj + 1;
end;
