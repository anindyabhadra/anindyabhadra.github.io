%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation example for "Exact sampling of the unobserved covariates 
% in Bayesian spline models for measurement error problems."
%
% Authors: A. Bhadra(bhadra@purdue.edu), R. J. Carroll
%(carroll@stat.tamu.edu)
%
% NOTE 1: Refer to the README file for direction. 
% 
% NOTE 2: This is the main Example call for Gaussian regression with 
% replicated surrogates. This program generates data and makes
% the relevant calls. There are no covariates measured
% without error.
%
% NOTE 3: Each function has a detailed listing of what it gives as output
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
myseed = 809021;
format compact;
rand('state',myseed);
randn('state',myseed);

numsimset = 100; %Numnber of simulated data sets

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize required variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sse_tn_pspline = 0;
sse_tn_bspline = 0;
sse_bayes = 0;
sse_simex = 0;
sse_naive = 0;

mse_tn_pspline = 0;
mse_tn_bspline = 0;
mse_bayes = 0;
mse_simex = 0;
mse_naive = 0;

sd_tn_pspline=0;
sd_tn_bspline=0;
sd_bayes=0;
sd_simex=0;
sd_naive=0;

naivetime = 0;
simextime = 0;
bayestime = 0;
tnptime = 0;
tnbtime = 0;

nxgrid     = 101;    % Number of grid values
xgrid      = linspace(-2,2,nxgrid)';
mean_tnfit_pspline = zeros(nxgrid,1);
mean_tnfit_bspline = zeros(nxgrid,1);
mean_bayesfit=zeros(nxgrid,1);
mean_simexfit=zeros(nxgrid,1);
mean_naivefit=zeros(nxgrid,1);

num_burn   = 500;   % Number of MCMC steps as a burn-in period
num_mcmc   = 3000;   % Number of MCMC steps after the burn-in period
tn_num_burn = 20;   % Number of MCMC steps as a burn-in period for truncated normal sampling
tn_num_mcmc = 350;  % Number of MCMC steps after the burn-in period for truncated normal sampling
meanparams_tnfit_pspline = zeros(tn_num_mcmc,6);
meanparams_tnfit_bspline = zeros(tn_num_mcmc,5);
meanparams_bayesfit=zeros(num_mcmc,6);


for indx = 1:numsimset

numsimex   = 1;    % Number of simex replications
n          = 500;   % The sample size
degree     = 1;      % Degree of the spline
nknots=25;
sigmasqx   = 1.0;    % The variance of X %anindya
sigmasqu   = 1.0;    % The error variance for U % anindya try 0.33, 0.5, 0.75, 1.0
sigmasqe   = .09;    % Regression error variance 
alambda    = 0.50;   % Lower bound for attenuation
blambda    = 1.00;   % Upper bound for attenuation
num_reps   = 2 .* ones(n,1); % Vector of number of replicates per individual
suknown_if = 0;   % = 1 if measurement error variance is known
lambda_update = 0;      % = 0 if you do a discrete search (recommended)
                     % = 1 if you do a M-H with a Gamma candidate

xx           = sqrt(sigmasqx) .* randn(n,1); 

ww1          = xx + (sqrt(sigmasqu) .* randn(n,1)); % Observed W
ww2          = xx + (sqrt(sigmasqu) .* randn(n,1)); % Observed W
wwbar        = (ww1 + ww2) ./ 2;
wwvar=var([ww1'; ww2']);
wwvar=wwvar';
hh           = wwbar;
sigmasqu_hat_rep = mean( (ww1 - hh) .^ 2) + mean( (ww2 - hh) .^ 2);
z            = (xx > 0);
a            = sin(pi .* xx ./ 2);
b            = 1 + (2 .* xx .* xx .* (z+1));
qqqq         = (3).*a ./ b;
yy           = qqqq + (sqrt(sigmasqe) .* randn(n,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the naive estimate 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
boundstab             = 1;
knots                 = quantileknots(wwbar,nknots,boundstab);
istd                  = 1;
extrapen              = 0;
penwt                 = logspace(-10,10,41);
tic;
fit_naive             = PsplineDR02_raymodified(wwbar,yy,degree,nknots,extrapen, ...
                                        penwt,boundstab,knots,istd,xgrid);
beta_naive            = fit_naive.beta;
toc;
naivetime = naivetime + toc
sigmasqe_hat          = fit_naive.sigma2hat;
xgridm                = powerbasis01(xgrid,degree,knots);
naive_fit             = (xgridm * beta_naive); % The naive fit
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Call the SIMEX regression spline
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
fit_simex       = simex_linear_measerror_reg_spl(yy,wwbar, ...
			sigmasqu_hat_rep,nknots,degree, ...
			xgrid,nxgrid,numsimex,num_reps);
simex_quadratic = fit_simex.quadex; % The simex fit on the grid
toc
simextime = simextime + toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call the Bayes Regression B-Spline with truncated normal sampling for x
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
tn_fit_bayes_bspline = tn_bayes_linear_me_bspline(tn_num_burn, ...
		    tn_num_mcmc,yy,wwbar,alambda, ...
		    blambda,nknots,degree,xgrid, ...
   		    sigmasqu_hat_rep,num_reps,suknown_if, ...
                    lambda_update);
tn_post_mean_fit_bspline = tn_fit_bayes_bspline.post_mean_fit;
params.bs=tn_fit_bayes_bspline.answer_parameters;
toc
tnbtime = tnbtime + toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call the Bayes Regression P-Spline with truncated normal sampling for x
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
tn_fit_bayes_pspline = tn_bayes_linear_me_regspline(tn_num_burn, ...
		    tn_num_mcmc,yy,wwbar,alambda, ...
		    blambda,nknots,degree,xgrid, ...
   		    sigmasqu_hat_rep,num_reps,suknown_if, ...
                    lambda_update);
tn_post_mean_fit_pspline = tn_fit_bayes_pspline.post_mean_fit;
params.ps=tn_fit_bayes_pspline.answer_parameters;
toc
tnptime = tnptime + toc


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call the Bayes Regression Spline with M-H MCMC for x
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
tic;
fit_bayes = bayes_linear_me_regspline(num_burn, ...
		    num_mcmc,yy,wwbar,alambda, ...
		    blambda,nknots,degree,xgrid, ...
   		    sigmasqu_hat_rep,num_reps,suknown_if, ...
                    lambda_update);
post_mean_fit = fit_bayes.post_mean_fit;
params.bayes=fit_bayes.answer_parameters;
toc
bayestime = bayestime + toc
bayesaccept = fit_bayes.bayesaccept



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot the functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
z            = (xgrid > 0);
a            = sin(pi .* xgrid ./ 2);
b            = 1 + (2 .* xgrid .* xgrid .* (z+1));
qqqq         = (3).*a ./ b;
clf;
hold on;
h1=plot(xgrid,qqqq,'k',xgrid,post_mean_fit,'b', ...
	  xgrid,naive_fit,'r', ...
          xgrid,simex_quadratic,'m',xgrid,tn_post_mean_fit_pspline,'g',xgrid,tn_post_mean_fit_bspline,'y');
legend('True','Bayes','Naive','SIMEX','PSPLINES', 'BSPLINES');
set(h1,'LineWidth',3);
hold off;
drawnow

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate running MSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t1 = sum((qqqq - tn_post_mean_fit_pspline).^2) - mse_tn_pspline;
mse_tn_pspline = ((indx - 1).* mse_tn_pspline + sum((qqqq - tn_post_mean_fit_pspline).^2))./indx;
mean_tnfit_pspline = ((indx - 1).* mean_tnfit_pspline + tn_post_mean_fit_pspline)./indx;
t2 = sum((qqqq - tn_post_mean_fit_pspline).^2) - mse_tn_pspline;
sd_tn_pspline = sd_tn_pspline + t1.*t2;

t1 = sum((qqqq - tn_post_mean_fit_bspline).^2) - mse_tn_bspline;
mse_tn_bspline = ((indx - 1).* mse_tn_bspline + sum((qqqq - tn_post_mean_fit_bspline).^2))./indx;
mean_tnfit_bspline = ((indx - 1).* mean_tnfit_bspline + tn_post_mean_fit_bspline)./indx;
t2 = sum((qqqq - tn_post_mean_fit_bspline).^2) - mse_tn_bspline;
sd_tn_bspline = sd_tn_bspline + t1.*t2;

t1 = sum((qqqq - post_mean_fit).^2) - mse_bayes;
mse_bayes = ((indx - 1).* mse_bayes + sum((qqqq - post_mean_fit).^2))./indx;
mean_bayesfit = ((indx - 1).* mean_bayesfit + post_mean_fit)./indx;
t2 = sum((qqqq - post_mean_fit).^2) - mse_bayes;
sd_bayes = sd_bayes + t1.*t2;

t1 = sum((qqqq - simex_quadratic).^2) - mse_simex;
mse_simex = ((indx - 1).* mse_simex + sum((qqqq - simex_quadratic).^2))./indx;
mean_simexfit = ((indx - 1).* mean_simexfit + simex_quadratic)./indx;
t2 = sum((qqqq - simex_quadratic).^2) - mse_simex;
sd_simex = sd_simex + t1.*t2;

t1 = sum((qqqq - naive_fit).^2) - mse_naive;
mse_naive = ((indx - 1).* mse_naive + sum((qqqq - naive_fit).^2))./indx;
mean_naivefit = ((indx - 1).* mean_naivefit + naive_fit)./indx;
t2 = sum((qqqq - naive_fit).^2) - mse_naive;
sd_naive = sd_naive + t1.*t2;

meanparams_tnfit_pspline = ((indx - 1).* meanparams_tnfit_pspline + params.ps)./indx;
meanparams_tnfit_bspline = ((indx - 1).* meanparams_tnfit_bspline + params.bs)./indx;
meanparams_bayesfit = ((indx - 1).* meanparams_bayesfit + params.bayes)./indx;

end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate final average MSE, sd of MSE and average time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mse_tn_pspline
sd_tn_pspline = sd_tn_pspline./numsimset

mse_tn_bspline
sd_tn_bspline = sd_tn_bspline./numsimset

mse_bayes
sd_bayes = sd_bayes./numsimset

mse_simex
sd_simex = sd_simex./numsimset

mse_naive
sd_naive = sd_naive./numsimset

tnptime = tnptime./numsimset
tnbtime = tnbtime./numsimset
bayestime = bayestime./numsimset
simextime = simextime./numsimset
naivetime = naivetime./numsimset

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plot the average fit
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h1=plot(xgrid,qqqq,'k',xgrid,mean_bayesfit,'b', ...
	  xgrid,mean_naivefit,'r', ...
          xgrid,mean_simexfit,'m',xgrid,mean_tnfit_pspline,'g',xgrid,mean_tnfit_bspline,'y');
legend('True','Bayes','Naive','SIMEX','PSPLINES', 'BSPLINES');
set(h1,'LineWidth',3);

%save('0514bsigsqu1.0.mat', 'mse_tn_bspline','mse_tn_pspline','mse_bayes', 'mse_simex', 'mse_naive', 'sd_tn_bspline','sd_tn_pspline','sd_bayes', 'sd_simex', 'sd_naive', 'tnbtime','tnptime','bayestime','simextime', 'naivetime','xgrid','qqqq','mean_bayesfit','mean_naivefit','mean_simexfit','mean_tnfit_bspline','mean_tnfit_pspline')