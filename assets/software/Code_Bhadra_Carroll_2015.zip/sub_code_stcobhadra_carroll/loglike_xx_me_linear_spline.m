function loglike = loglike_xx_me_linear_spline(xx,yy, ...
			beta,vv_beta,knots,nknots,degree, ...
			wwbar,sigmasqu,mux,sigmasqx,sigmasqe, ...
			num_reps);
%
%
% This computes the loglikelihood contribution for X,
% as a vector, in the P-spline for Gaussian regression
% with measurement error and replicates
% 
% INPUT:
%      The values of xx to be evaluated
%      The response yy
%      The current value of beta
%      The number of knots, nknots
%      The actual knots, knots
%      The degree of the regression spline
%      wwbar    = unbiased predictor mean of num_reps
%                          replications 
%      sigmasqu = current value of var(U)
%      sigmasqx = current value of var(X)
%      sigmasqe = current value of var(epsilon)
%      mux      = current value of  E(X)
%
% OUTPUT:
%      The loglikelihood
%
%
xm = powerbasis(xx,degree,knots);
csum    = xm * beta;
loglike = -( (yy - csum) .^ 2) ./ (2 .* sigmasqe);
loglike = loglike - ( ((wwbar - xx) .^ 2) ./ ...
		      (2 .* sigmasqu ./ num_reps)) ...
          - ( ((xx - mux) .^ 2) ./ (2 .* sigmasqx));



