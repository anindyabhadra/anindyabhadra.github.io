function fit = simex_linear_measerror_reg_spl(yy,wwbar, ...
			sigmasqu,nknots,degree, ...
			xgrid,nxgrid,numsimex,num_reps)
%
%
% This program computes the SIMEX estimator
% for Gaussian regression with a variable
% wwbar measured with error, with the fit by a
% penalized regression spline. This is not
% restricted to IV problems: it is simply a 
% standard additive measurement error program
%
% The special feature of this program is that it
% allows for a different number of replciates
% per unit in computing the surrogate
%
% SPECIAL NOTE: This program requires that there
%               by 5 simex lambda values, namely
%               0.0, 0.5, 1.0, 1.5 and 2.0. In principle,
%               by using three-dimensional arrays, you
%               can make this slightly more general.
%
% INPUT:
%        yy        = quantitaive response
%        wwbar     = error-prone covariate, the mean of num_reps
%                    replciates 
%        num_reps  = Number of replicates
%        sigmasqu  = error variance estimate
%        nknots    = number of knots
%        degree    = degree of the polynomial
%        xgrid     = grid of values on which function is evaluated
%        nxgrid    = number of grid points
%        numsimex  = number of simex replications
%
% OUTPUT
%        linex     = simex    linear extrapolant on grid
%        quadex    = simex quadratic extrapolant on grid
%
%
n        = rows(yy);
answer1  = zeros(numsimex,nxgrid);
answer2  = zeros(numsimex,nxgrid);
answer3  = zeros(numsimex,nxgrid);
answer4  = zeros(numsimex,nxgrid);
answer5  = zeros(numsimex,nxgrid);
x2       = [];
%
% First get the naive fit, ignoring measurement error
%
      squ = 0;
      vv = wwbar;
      boundstab   = 1;
      knots       = quantileknots(vv,nknots,boundstab);
      istd        = 1;
      extrapen    = 0;
      penwt       = logspace(-10,10,41);
      knots       = quantileknots(vv,nknots,boundstab);
      xgridm      = powerbasis01(xgrid,degree,knots);
      results     = PsplineDR02_raymodified(vv,yy,degree, ...
			nknots,extrapen, ...
                        penwt,boundstab,knots,istd, ...
                        xgrid);
      naive_fit   = results.mhat';
% Now run the SIMEX simulation
for kk = 1:numsimex;
  for jj=1:5;
    if jj == 1;
	answer1(kk,:) = naive_fit;
    end;
    if jj > 1;
      squ = sigmasqu .* (jj-1) ./ 2.0;
      uu = generate_simex_pseudo_errors(squ,wwbar);
      mmmm = var(uu) ./ squ;
      vv   = wwbar + (uu ./ sqrt(num_reps));
      boundstab   = 1;
      knots       = quantileknots(vv,nknots,boundstab);
      istd        = 1;
      extrapen    = 0;
      penwt       = logspace(-10,10,41);
      knots       = quantileknots(vv,nknots,boundstab);
      xgridm      = powerbasis01(xgrid,degree,knots);
      results     = PsplineDR02_raymodified(vv,yy,degree, ...
			nknots,extrapen, ...
                        penwt,boundstab,knots,istd, ...
                        xgrid);
      if jj == 2;
	answer2(kk,:) = results.mhat';
      end;
      if jj == 3;
	answer3(kk,:) = results.mhat';
      end;
      if jj == 4;
	answer4(kk,:) = results.mhat';
      end;
      if jj == 5;
	answer5(kk,:) = results.mhat';
      end;
    end;
  end;
end;

bnswer1 = mean(answer1,1);
bnswer2 = mean(answer2,1);
bnswer3 = mean(answer3,1);
bnswer4 = mean(answer4,1);
bnswer5 = mean(answer5,1);

linex   = zeros(nxgrid,1);
quadex  = zeros(nxgrid,1);
for jj=1:nxgrid;
  cc = [bnswer1(1,jj) bnswer2(1,jj) bnswer3(1,jj) ...
	bnswer4(1,jj) bnswer5(1,jj) ]';
  ll = [0.0 0.5 1.0 1.5 2.0]';
  dd = [ones(5,1) ll];
  bb = inv(dd' * dd) * dd' * cc;
   linex(jj,1) = bb(1,1) - bb(2,1);
  dd = [ones(5,1) ll (ll .^ 2)];
  bb = inv(dd' * dd) * dd' * cc;
  quadex(jj,1) = bb(1,1) - bb(2,1) + bb(3,1);
end;

  
fit = struct('linex',linex,'quadex',quadex, ...
	     'answer1',answer1, ...
	     'answer2',answer2, ...
	     'answer3',answer3, ...
	     'answer4',answer4, ...
	     'answer5',answer5) ; 

