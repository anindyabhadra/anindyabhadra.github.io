function fit = tn_bayes_linear_me_regspline(num_burn, ...
		num_mcmc,yy,wwbar, ...
		alambda,blambda,nknots,degree,xgrid, ...
		sigmasqu_hat_rep,num_reps,suknown_if, ...
                lambda_update);

%NOTE: Truncated normal sampling can be used only if degree of spline = 1
% Program for Bayes MCMC in the Gaussian spline
% measurement error problem with replicates
%  Y_i    =  C_1^T(X_i) beta_1 + C_2^T(X_i) beta_2 + epsilon_i
%  W_{ij} = X_i + U_{ij}
%  beta_2 = Normal(0, (1 ./ gamma)I)
%  lambda = var(X) ./ (var(X) + var(U)
%  var(U) = var(X) (1-lambda)/lambda
%
% INPUT
%       yy               : Response
%       wwbar            : unbiased predictor mean of num_reps
%                          replications 
%       sigmasqu_hat_rep : Variance estimate of measurement error
%                          variance from formula (3.2) in carroll,
%                          Ruppert and Stefanski. If the
%                          measurement error variance is known,
%                          this is the known measurement error variance
%       num_reps         : Number of replicates for each data
%                          observation (= k_i in Carroll, et
%                          al). This is a vector of length n 
%       suknown_if       : = 1 if the measurement error variance is
%                          known and need not be updated in the
%                          MCMC steps
%                        : = 0 otherwise
%       num_burn         : Number of MCMC steps as a burn-in period
%       num_mcmc         : Number of MCMC steps after the burn-in period
%       alambda          : Lower bound for attenuation lambda
%       blambda          : Upper bound for attenuation lambda
%                          This program never allows you to
%                          use a value > 0.95, on the principle
%                          that you would not be doing an IV
%                          regression if you thought there was
%                          no measurement error.
%       nknots           : The number of knots
%       degree           : The degreee of the regression spline
%       xgrid            : The grid of values for which the
%                        : logists are to be evaluated
%       lambda_update    : = 0 if you do a discrete search (recommended)  
%                        : = 1 if you do a M-H with a Gamma candidate 
%
% OUTPUT:
% A structure with the following elements
% answer_parameters: a num_mcmc by 6 matrix of MCMC samples,
%                    the columns of which are 
%        		     lambda mux sigmasqx sigmasqu mygamma (the 
%                    variance component for the random effects)
%        		     and sigmasqe
% answer_betas     : a num_mcmc by 1 + degree + nknots matrix
%                    containing the MCMC generations of the betas
% xgrid_matrix     : this is the "design matrix" for the grid.
%                    Let nxgrid be the number of grid points.
%                    Then (xgrid_matrix * answer_betas')' is the 
%                    num_mcmc by nxgrid points giving the MCMC
%                    results for the function fitted on the grid
% post_mean_fit    : The posterior mean fit to the logist,
%                    on the grid, a vector  with one column
% knots            : The knots used in the analysis
% mix_xx           : The percentage of mixing for the Metropolos
%                    Hastings steps for X
% SPECIAL NOTE: To get the posterior means of the logits, use the code
%         answer_parameters = mean(answer_parameters,1);
%         answer_betas      = mean(answer_betas,1);

ww = wwbar;
if (degree ~= 1) 
    disp('Caution: Truncated normal sampling can be used only for degree = 1');
    return
end
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set Prior Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ax         = 1;      % First parameter  in IG prior for var(X)
bx         = 1;      % Second parameter in IG prior for var(X)
ae         = 1;      % First parameter  in IG prior for var(epsilon)
be         = 1;      % Second parameter in IGprior for var(epsilon)
vv_mu      = 100;    % Prior variance for mu_x
vv_beta    = 100;    % Prior variance for (beta_0,beta_1)
agamma     = .01;    %  First Gamma parameter for gamma 
bgamma     = 100;    % Second Gamma parameter for gamma 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get Naive Fit and define the knots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
boundstab     = 0;
knots         = quantileknots(wwbar,nknots,boundstab);
istd          = 1;
extrapen      = 0;
penwt         = logspace(-10,10,41);
xgrid_matrix  = powerbasis01(xgrid,degree,knots);
fit_naive     = PsplineDR02_raymodified(wwbar,yy,degree, ...
	            		nknots,extrapen, ...
                        penwt,boundstab,knots,istd, ...
                        xgrid);
beta_naive    = real(fit_naive.beta);
sigmasqe_hat  = fit_naive.sigma2hat;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get method of moments parameter
% estimates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmasqu_hat = sigmasqu_hat_rep;
mux_hat      = num_reps' * wwbar ./ sum(num_reps);
sigmasqx_hat = var(wwbar) - (sigmasqu_hat .* mean(1 ./ num_reps));
sigmasqx_hat = max( [ 0.01 sigmasqx_hat]);
%
% Now begin the MCMC
%
mix_xx         = 0;
n              = rows(yy);
lambda_hat     = sigmasqx_hat ./ (sigmasqx_hat + sigmasqu_hat);
if lambda_hat < alambda;
    lambda_hat = alambda + (rand(1,1) .* (blambda - alambda));
end;
if lambda_hat > blambda;
    lambda_hat = alambda + (rand(1,1) .* (blambda - alambda));
end;
lambda         = lambda_hat;
sigmasqx       = sigmasqx_hat;
sigmasqe       = sigmasqe_hat;
sigmasqu       = sigmasqu_hat;
mux            = mux_hat;
beta           = beta_naive;
answer_parameters ...
               = zeros(num_burn+num_mcmc,6);
answer_betas      ...
               = zeros(num_burn+num_mcmc,1+degree+nknots);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get initial estimate of X as the conditional 
% mean of X given    Wbar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Note: Begin: Unnecessary for truncated normal sampling. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% bigD    = 1 ./ ((1 ./ sigmasqx) + ...
% 		(num_reps ./ sigmasqu));
% if abs(imag(bigD)) > 0;
%   disp('bigD before mcmc is imaginary')
% end;
% if bigD <  0;
%   disp('bigD before mcmc is negative')
% end;
% if sigmasqu < 0;
%   disp('sigmasqu before mcmc is negative')
% end;
% if sigmasqx < 0;
%   disp('sigmasqx before mcmc is negative')
% end;
% if lambda < 0;
%   disp('lambda before mcmc is negative')
% end;
% if lambda > 1;
%   disp('lambda before mcmc is > 1')
% end;
% 
% 
% smalld  = (mux ./ sigmasqx) + ...
% 	  (wwbar .* num_reps ./ sigmasqu);
% xx      = bigD .* smalld;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Note: End: Unnecessary for truncated normal sampling. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for jjmcmc=1:(num_burn + num_mcmc);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Set the value of sigmasqu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if suknown_if == 0;
    sigmasqu = sigmasqx .* (1 - lambda) ./ lambda;
    if abs(imag(sigmasqu)) > 0;
      disp('Underflow in sigmasqu')
    end;
    if sigmasqu <  0;
      disp('negative sigmasqu')
    end;
  end;
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Generate a value of gamma
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  aa = agamma + (nknots ./ 2);
  cc = beta((2+degree):(1+degree+nknots),:);
  bb = 1 ./ ( (1 ./ bgamma) + (cc' * cc ./ 2));
  mygamma = gamrnd(aa,bb,1,1);
  if abs(imag(mygamma)) > 0;
    disp('Underflow in mygamma')
  end;
  
%%%%%%%%%%%%% Generate new value of x %%%%%%%%%
%%%%%%%%%%%% begin:  mixture of truncated normal sampling for x, anindya  3/6/13 %%%%%%%%%%%
%%%%% Step 1. Compute C1, C2 and C3 %%%%%%%%%%%
theta = beta([3:end]);
tt = [0; theta];
kk = [-500000; knots];
ppp = ((1./sigmasqe).*(beta(2) + cumsum(tt)).^2) + 1./sigmasqx;
ttt = num_reps./sigmasqu;
C1 = 1./(ones(n,1)*ppp' + ttt*ones(1,nknots+1));
C2 = (-1./(2.*sigmasqe)).*(-2.*beta(2).*yy*ones(1,nknots+1) - 2.*yy*cumsum(tt)' + 2.*(beta(1) - ones(n,1)*(cumsum(tt.*kk))').*(beta(2) + ones(n,1)*cumsum(tt)')) + (wwbar.*num_reps./sigmasqu)*ones(1,nknots+1) + mux/sigmasqx;
C3 = (-1./(2.*sigmasqe)).* (2.*yy*cumsum(tt.*kk)' + (beta(1) - ones(n,1)*cumsum(tt.*kk)').^2);
%%%%%%% Step 2. Compute means and sd for trnctaed normals %%%%
mumu = C2.*C1;
sigsig = (C1).^(0.5);
%%%%%%%%% Step 3. Define the knots: -Inf, Existing knots, +Inf %%%%%
kk1 = [-Inf; knots];
kk2 = [knots; Inf];
lb = ones(n,1)*kk1';
rb =  ones(n,1)*kk2';
%%%%%%%%% Step 4: Compute mixture probabilities and normalize %%%%%%
MM = sigsig.*exp(C3 + C1.*((C2).^2)./2);
prr = MM.*(normcdf(rb, mumu, sigsig) - normcdf(lb, mumu, sigsig));
ll=sum(prr,2);
prr = prr./(ll*ones(1, nknots+1));
%%%%%%%%% Step 5: Sample an indicator according to mixture probabilities
%%%
cs = cumsum(prr,2);
lok = rand(n,1)*ones(1,nknots+1) - cs;
er = subplus(lok);
indd = sum(er~=0,2)+1;
idx=sub2ind(size(lb),1:n,indd');
%%%%%%%%%% Step 6: Sample from the truncated normals %%%%%%
%%%%%%%%%% The file rtnorm.m is available at
%%%%%%%%%% http://miv.u-strasbg.fr/mazet/rtnorm/rtnorm-fr.htm %%%%%
xx=arrayfun(@rtnorm,lb(idx)',rb(idx)',mumu(idx)',sigsig(idx)');

%%% as an alternative for arrayfun, use the line below %%%
%for (i =1:n) xx(i) = rtnorm(lb(idx(i)), rb(idx(i)), mumu(idx(i)), sigsig(idx(i))); end

%%%%%%%%%%%% end: mixture of truncated normal sampling for x, anindya 3/6/13 %%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Generate the basis functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  xmatrix = powerbasis01(xx,degree,knots);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Update var(epsilon)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
aa           = ae + (n ./ 2);
bb           = 1 ./ ( (1 ./ be) + ...
		(sum( (yy - (xmatrix * beta)) .^ 2) ./ 2));
cc           = gamrnd(aa,bb,1,1);
dd           = 1 ./ cc;
if dd <  1.5 .* var(yy);
  sigmasqe     = 1 ./ cc;
end;
if abs(imag(sigmasqe)) > 0;
  disp('Underflow in sigmasqe')
end;
if sigmasqe <  0;
  disp('negativesigmasqe')
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Update var(X)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
aa           = ax + (n ./ 2) + sum(num_reps ./ 2);
gg           = (lambda ./ (1 - lambda)) .* ...
                  sum( ((wwbar - xx) .^ 2) ./ (2 ./ num_reps));
qw           = (lambda ./ (1 - lambda)) .* ...
                  sum(sigmasqu_hat_rep .* sum(num_reps - 1) ./ 2);
hh           = sum( (xx - mux) .^ 2) ./ 2;
bb           = 1 ./ ( (1 ./ bx) + gg + hh + qw);
  if suknown_if == 1;
    aa           = ax + n;
    bb           = 1 ./ ( (1 ./ bx) + gg + hh);
  end;
cc           = gamrnd(aa,bb,1,1);
dd           = 1 ./ cc;
if dd < 1.5 .* var(wwbar);
  sigmasqx     = 1 ./ cc;
end;
if abs(imag(sigmasqx)) > 0;
  disp('Underflow in sigmasqx')
end;
if sigmasqx < 0;
  disp('negative sigmasqx')
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Update mux
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
aa           = (sum(xx) .* vv_mu) ./ ...
               (sigmasqx + (n .* vv_mu));
bb           = sigmasqx .* vv_mu ./ ...
               (sigmasqx + (n .* vv_mu));
mux          = aa + (sqrt(bb) .* randn(1,1));
if abs(imag(mux)) > 0;
  disp('mux is imaginary')
  disp(['aa = ' num2str(aa)])
  disp(['bb = ' num2str(bb)])
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Update the beta's
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
qqggff       = max(0.0001,sigmasqe .* mygamma);
bigAmat      = qqggff .* eye(1+degree+nknots);
for jjpp=1:(1+degree);
  bigAmat(jjpp,jjpp) = sigmasqe ./ vv_beta;
end;
qqggff       = (xmatrix' * xmatrix) + bigAmat;
ppggff       = cols(xmatrix);
if rank(qqggff) < ppggff;
  disp('Underflow in bayes linear spline.m')
end;

if rank(qqggff) == ppggff; 
  qmatrix      = sigmasqe .* inv(qqggff);
  hmatrix      = xmatrix' * yy  ./ sigmasqe;
  aa           = qmatrix * hmatrix;
  bb           = sqrtm(qmatrix);
  cc           = bb * randn(1+degree+nknots,1);
  qqwwbaree         = aa + cc;
  if abs(imag(qqwwbaree)) == 0;
    beta = qqwwbaree;
    end;
  if abs(imag(qqwwbaree)) > 0;
    disp('Underflow in beta')
    end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Update lambda, if var(U) is unknown
% lambda_update = 0 if you do a discrete search
% lambda_update = 1 if you do a M-H with a Gamma candidate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if suknown_if == 1;
  lambda = sigmasqx ./ (sigmasqx + sigmasqu);
end;
if suknown_if == 0;
  aa           = 1 + (sum(num_reps) ./ 2);
  bb1          = sum(num_reps .* ((wwbar - xx) .^ 2)) ./ ...
                     (2 .* sigmasqx);
  bb2          = sigmasqu_hat_rep .* sum(num_reps - 1) ./ ...
                     (2 .* sigmasqx);
  bb           = 1 ./ (bb1 + bb2);
lambda_old      = lambda;
if lambda_update == 0;
lammax          = min(0.99,blambda);
lambda_discrete = linspace(alambda,lammax,40)';
theta_discrete  = lambda_discrete ./ (1 - lambda_discrete);
dd              = ( (aa-1) .* log(theta_discrete)) ...
                     - (theta_discrete ./ bb);
dd              = dd - max(dd);
dd              = exp(dd);
dd              = dd ./ sum(dd);
uu              = rand(1,1);
ff              = zeros(40,1);
ff(1,1)         = dd(1,1);
for jj=2:40;
  ff(jj,1)      = dd(jj,1) + ff(jj-1,1);
end;
if uu <= dd(1,1);
  lambda        = lambda_discrete(1,1);
end;
if uu > dd(1,1);
  for jj = 2:40;
      if uu <= ff(jj,1);
	if uu > ff(jj-1,1);
	  lambda = lambda_discrete(jj,1);
	end;
      end;
  end;
end;
end;

if lambda_update == 1;
theta_old    = lambda_old ./ (1 - lambda_old);
theta_cand   = gamrnd(aa,bb,1,1);
lambda_cand  = theta_cand ./ (1 + theta_cand);
RR           = ( (1 + theta_old) .^ 2) ./ ((1 + theta_cand).^2);
aa           = (rand(1,1) < RR);
if lambda_cand < alambda; 
     aa = 0;
end;
if lambda_cand > blambda; 
     aa = 0;
end;
lambda       = ((1-aa) .* lambda_old) + (aa .* lambda_cand);
end;

end;


answer_parameters(jjmcmc,:) = ...
                    [lambda mux sigmasqx sigmasqu sigmasqe mygamma];
answer_betas(jjmcmc,:) ...
                 = beta';
end;
answer_parameters ...
                 = answer_parameters((1+num_burn):(num_burn+num_mcmc),:);
answer_betas ...
                 = answer_betas((1+num_burn):(num_burn+num_mcmc),:);
post_mean_fit    = mean((xgrid_matrix * answer_betas')',1)';

fit              = struct('answer_parameters',answer_parameters, ...
		   'answer_betas',answer_betas, ...
		   'mix_xx',mix_xx, ...
		   'xgrid_matrix',xgrid_matrix, ...
	           'post_mean_fit',post_mean_fit, ...
			  'knots',knots);



