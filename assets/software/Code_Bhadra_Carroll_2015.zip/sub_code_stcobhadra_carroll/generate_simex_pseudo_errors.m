function fit = generate_simex_pseudo_errors(sigsqu,xx)
%
% This program generates simex pseudo errors
% You have to pass it the error variance sigsqu
%     and the matrix with which you want the 
%     pseudoerrors to be uncorrelated
%
% Generally, xx consists of the response variable
% and all independent variables in your regression
%
n  = rows(xx);
m  = cols(xx);
uu = randn(n,1);
dd = [ones(n,1) xx];
bb = inv(dd' * dd) * dd' * uu;
rr = uu - (dd * bb);
cc = n .* sigsqu ./ ( (n - m - 1) .* mean(rr .^ 2));
fit = rr .* sqrt(cc);


